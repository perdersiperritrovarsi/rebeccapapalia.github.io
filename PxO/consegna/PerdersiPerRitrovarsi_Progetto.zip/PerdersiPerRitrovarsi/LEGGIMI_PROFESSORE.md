# Perdersi, ritrovarsi — consegna del progetto

Questo archivio contiene il sito completo e il codice modificabile.
Versione del sito: commit 2d829fd del repository perdersiperritrovarsi/rebeccapapalia.github.io.

## Aprire il sito

1. Estrarre completamente lo ZIP, mantenendo le cartelle.
2. Aprire `incontro.html` in un browser moderno per la vista con entrambe le serie.
3. I menu in alto portano a Perdersi (`perdersi.html`), Ritrovarsi (`index.html`)
   e Incontro (`incontro.html`).

Il sito incorpora cartografia e traiettorie nelle pagine. Non richiede account,
chiavi API o installazione di pacchetti. Solo i link a Google Maps e Street View
richiedono Internet; la disponibilità delle fotografie dipende da Google.

Per usare il sito tramite un server locale, con Python 3 installato, aprire un
terminale nella cartella estratta ed eseguire:

```sh
python3 -m http.server 8000
```

Su Windows si può usare `py -3 -m http.server 8000`.
Aprire poi nel browser `http://localhost:8000/incontro.html`.
Per terminare il server premere Ctrl+C nel terminale.

## Contenuti e modifiche

- `tools/ink.html`: struttura, testi e stili delle tre viste principali.
- `tools/ink.js`: pigmenti, animazione, cartografia, zoom, schede dei luoghi e JPEG.
- `tools/build_html.py`: rigenera le pagine complete, le copie compatibili e gli ZIP GPX.
- `tools/page.html`: template delle versioni a linee.
- `gpx/P01.gpx`–`P15.gpx`: serie Ritrovarsi.
- `gpx/perdersi/P01.gpx`–`P15.gpx`: serie Perdersi.
- `assets/`: cartografia, grafo stradale, fonti, licenze e report delle traiettorie.
- `README.md`: documentazione tecnica, provenienza dei dati e sviluppo delle funzioni.

Dopo aver modificato template, renderer o GPX, eseguire dalla cartella principale:

```sh
python3 tools/build_html.py
```

Poi ricaricare la pagina nel browser. Il generatore usa solo la libreria standard
Python. Modificare direttamente gli HTML generati è possibile, ma quelle modifiche
verranno sovrascritte alla successiva generazione: preferire i file in `tools/`.
Non è necessario eseguire i generatori delle traiettorie né scaricare nuove mappe
per modificare testi, colori o grafica.

Gli ID P01–P15 si ripetono nelle due serie: mantenerle nelle cartelle distinte.
I metadati GPX e il README distinguono registrazioni originali e traiettorie
artistiche generate. Preservare questa provenienza, le fonti e le attribuzioni.

## Funzioni disponibili

Riproduzione e pausa, ricerca temporale, velocità, visibilità delle tracce,
colori indipendenti e diffusione iniziale Delicata. La cartografia monocromatica
emerge lungo i cammini; alla fine appare la stampa completa con margini sfumati.
Lo zoom supporta rotella, pinch, trascinamento, pulsanti e tastiera. Il simbolo ⌖
accanto a una presenza apre la scheda geografica anche in caso di sovrapposizione.
Il pulsante JPEG salva la composizione finale con le presenze visibili e i colori
scelti: `Cartografia_PerdersiPerRitrovarsi.jpg`, 1600×1146 pixel.

## Sito pubblico

https://perdersiperritrovarsi.github.io/rebeccapapalia.github.io/PxO/incontro.html

Le modifiche effettuate a questa copia locale non cambiano automaticamente il
sito pubblico. Per pubblicarle occorre consegnare i file aggiornati alla titolare
o avere accesso al repository GitHub. Non sono incluse credenziali nell'archivio.
La cartella GitHub `PxO` e gli alias `pxo.html` sono mantenuti per compatibilità
con i link condivisi in precedenza; il terzo menu corrente si chiama Incontro.
